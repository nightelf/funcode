<?php
ini_set('default_charset', 'utf-8');
date_default_timezone_set('America/Los_Angeles');
spl_autoload_register();
